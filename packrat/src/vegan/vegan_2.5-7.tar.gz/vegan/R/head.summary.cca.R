`head.summary.cca` <-
    function(x, n=6, tail = 0, ...) {
        print(x, head=n, tail=tail, ...)
    }

`tail.summary.cca` <-
    function(x, n=6, head = 0, ...) {
        print(x, head=head, tail=n, ...)
    }
