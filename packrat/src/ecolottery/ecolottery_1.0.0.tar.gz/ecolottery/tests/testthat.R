library(testthat)
library(ecolottery)

test_check("ecolottery")