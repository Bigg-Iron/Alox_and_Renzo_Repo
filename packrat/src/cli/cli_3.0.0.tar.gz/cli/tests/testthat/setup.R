
withr::defer(.Call(clic__gcov_flush), teardown_env())
